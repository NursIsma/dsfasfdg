from django.urls import path

from . import views

urlpatterns = [
    path('fio', views.fio, name='fio'),
    path('about', views.about, name='about'),
    path('contacts', views.contacts, name='contacts'),
]
